package com.sss.as.response;

import com.sss.as.basemqttmsgformat.BaseMqttMessageResponse;
import com.sss.as.request.appcontrol.DeviceControl;

public class ControlSessionResponse extends BaseMqttMessageResponse {

    public Payload Payload = new Payload();

    public static class Payload {

        public DeviceControl deviceControl = new DeviceControl();

        public DeviceControl getDeviceControl() {
            return deviceControl;
        }

        public void setDeviceControl(DeviceControl deviceControl) {
            this.deviceControl = deviceControl;
        }
    }


    public Payload getPayload() {
        return Payload;
    }

    public void setPayload(Payload payload) {
        Payload = payload;
    }
}