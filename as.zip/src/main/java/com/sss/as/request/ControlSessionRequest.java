package com.sss.as.request;

import com.sss.as.basemqttmsgformat.BaseMqttMessage;

public class ControlSessionRequest extends BaseMqttMessage {
    public Payload Payload = new Payload();

    public static class Body {
        public String AppID;
        public String AppDeveloperID;
        public String AppInstanceID;
        public String AccessToken;
        public String DeviceID;
    }

    public static class Payload {
        public Body Body = new Body();
    }
}
